"use client"

import { useState } from "react"
import { ArrowLeft, TrendingUp, Calendar, BarChart3, Heart } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useRouter } from "next/navigation"
import { Badge } from "@/components/ui/badge"

// Mock mood history data
const moodHistory = [
  {
    id: 1,
    mood: { emoji: "😊", label: "Happy", value: 7 },
    note: "Had a great day at work and enjoyed lunch with friends",
    triggers: ["Work/School", "Relationships"],
    activities: ["Talking to someone", "Exercise"],
    timestamp: "2024-01-15T14:30:00Z",
  },
  {
    id: 2,
    mood: { emoji: "😟", label: "Worried", value: 3 },
    note: "Feeling anxious about upcoming presentation",
    triggers: ["Work/School"],
    activities: ["Breathing exercises", "Meditation"],
    timestamp: "2024-01-15T09:15:00Z",
  },
  {
    id: 3,
    mood: { emoji: "🙂", label: "Content", value: 6 },
    note: "Peaceful morning with coffee and reading",
    triggers: ["Personal Goals"],
    activities: ["Reading", "Meditation"],
    timestamp: "2024-01-14T08:00:00Z",
  },
  {
    id: 4,
    mood: { emoji: "😴", label: "Tired", value: 4 },
    note: "Long day, need more sleep",
    triggers: ["Sleep", "Work/School"],
    activities: ["Resting"],
    timestamp: "2024-01-13T22:30:00Z",
  },
]

export default function MoodTrackerPage() {
  const router = useRouter()
  const [selectedPeriod, setSelectedPeriod] = useState<"week" | "month">("week")

  const formatDate = (timestamp: string) => {
    const date = new Date(timestamp)
    return date.toLocaleDateString([], {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  const averageMood = moodHistory.reduce((sum, entry) => sum + entry.mood.value, 0) / moodHistory.length

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-emerald-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-teal-500 to-emerald-500 text-white p-4 shadow-lg">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="sm" onClick={() => router.back()} className="text-white hover:bg-white/20 p-2">
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <h1 className="font-semibold text-lg flex items-center gap-2">
              <Heart className="h-5 w-5" />
              Mood Tracker
            </h1>
            <p className="text-sm text-white/80">Track your emotional journey</p>
          </div>
        </div>
      </div>

      <div className="p-4 max-w-2xl mx-auto space-y-6">
        {/* Stats Overview */}
        <div className="grid grid-cols-2 gap-4">
          <Card>
            <CardContent className="p-4 text-center">
              <TrendingUp className="h-6 w-6 text-teal-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-teal-600">{averageMood.toFixed(1)}</div>
              <div className="text-sm text-muted-foreground">Average Mood</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <Calendar className="h-6 w-6 text-emerald-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-emerald-600">{moodHistory.length}</div>
              <div className="text-sm text-muted-foreground">Entries This Week</div>
            </CardContent>
          </Card>
        </div>

        {/* Period Selector */}
        <div className="flex gap-2">
          <Button
            variant={selectedPeriod === "week" ? "default" : "outline"}
            size="sm"
            onClick={() => setSelectedPeriod("week")}
            className="flex-1"
          >
            This Week
          </Button>
          <Button
            variant={selectedPeriod === "month" ? "default" : "outline"}
            size="sm"
            onClick={() => setSelectedPeriod("month")}
            className="flex-1"
          >
            This Month
          </Button>
        </div>

        {/* Mood History */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <BarChart3 className="h-5 w-5" />
              Recent Entries
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {moodHistory.map((entry) => (
              <div key={entry.id} className="p-4 bg-gray-50 rounded-lg space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{entry.mood.emoji}</span>
                    <div>
                      <div className="font-medium text-sm">{entry.mood.label}</div>
                      <div className="text-xs text-muted-foreground">{formatDate(entry.timestamp)}</div>
                    </div>
                  </div>
                  <Badge variant="outline" className="text-xs">
                    {entry.mood.value}/10
                  </Badge>
                </div>

                {entry.note && <p className="text-sm text-gray-700 bg-white p-3 rounded-md">{entry.note}</p>}

                {entry.triggers.length > 0 && (
                  <div>
                    <div className="text-xs font-medium text-muted-foreground mb-2">Triggers:</div>
                    <div className="flex flex-wrap gap-1">
                      {entry.triggers.map((trigger) => (
                        <Badge key={trigger} variant="secondary" className="text-xs">
                          {trigger}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {entry.activities.length > 0 && (
                  <div>
                    <div className="text-xs font-medium text-muted-foreground mb-2">Helpful Activities:</div>
                    <div className="flex flex-wrap gap-1">
                      {entry.activities.map((activity) => (
                        <Badge key={activity} variant="outline" className="text-xs">
                          {activity}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Insights */}
        <Card className="bg-gradient-to-r from-teal-50 to-emerald-50 border-teal-200">
          <CardContent className="p-6">
            <h3 className="font-semibold text-teal-800 mb-3 flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Weekly Insights
            </h3>
            <div className="space-y-2 text-sm text-teal-700">
              <p>• Your mood tends to be higher in the mornings</p>
              <p>• Exercise and talking to someone boost your mood the most</p>
              <p>• Work stress appears to be your main mood trigger</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
