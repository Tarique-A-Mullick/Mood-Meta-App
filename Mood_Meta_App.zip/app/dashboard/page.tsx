import { DashboardHeader } from "@/components/dashboard-header"
import { MoodGraph } from "@/components/mood-graph"
import { CommunityFeed } from "@/components/community-feed"
import { MoodSelector } from "@/components/mood-selector"
import { SOSButton } from "@/components/sos-button"
import { ChatButton } from "@/components/chat-button"
import { Heart, TrendingUp, Users } from "lucide-react"

export default function DashboardPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-purple-50/30 to-teal-50/30 relative overflow-hidden">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 right-10 w-32 h-32 bg-gradient-to-br from-purple-200/20 to-teal-200/20 rounded-full blur-2xl animate-pulse"></div>
        <div className="absolute bottom-40 left-10 w-40 h-40 bg-gradient-to-tr from-teal-200/20 to-purple-200/20 rounded-full blur-2xl animate-pulse delay-1000"></div>
      </div>

      <DashboardHeader />

      <main className="container mx-auto px-4 py-8 pb-32 space-y-8 animate-fade-in relative z-10">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-teal-600 bg-clip-text text-transparent mb-2">
            Welcome back to Mood Meta
          </h1>
          <p className="text-slate-600 text-lg">How are you feeling today?</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 shadow-lg border border-purple-100">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl">
                <Heart className="h-6 w-6 text-white" />
              </div>
              <div>
                <p className="text-sm text-slate-600">Mood Streak</p>
                <p className="text-2xl font-bold text-slate-800">7 days</p>
              </div>
            </div>
          </div>

          <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 shadow-lg border border-teal-100">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-gradient-to-br from-teal-500 to-teal-600 rounded-xl">
                <TrendingUp className="h-6 w-6 text-white" />
              </div>
              <div>
                <p className="text-sm text-slate-600">Progress</p>
                <p className="text-2xl font-bold text-slate-800">+15%</p>
              </div>
            </div>
          </div>

          <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 shadow-lg border border-purple-100">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-gradient-to-br from-purple-500 to-teal-500 rounded-xl">
                <Users className="h-6 w-6 text-white" />
              </div>
              <div>
                <p className="text-sm text-slate-600">Community</p>
                <p className="text-2xl font-bold text-slate-800">Active</p>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16 min-h-[600px]">
          <div className="space-y-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-gradient-to-br from-purple-500 to-purple-600 rounded-lg">
                <TrendingUp className="h-5 w-5 text-white" />
              </div>
              <h2 className="text-2xl font-bold text-slate-800">Your Mood Journey</h2>
            </div>
            <MoodGraph />
          </div>

          <div className="space-y-6 mt-8 lg:mt-0">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-gradient-to-br from-teal-500 to-teal-600 rounded-lg">
                <Users className="h-5 w-5 text-white" />
              </div>
              <h2 className="text-2xl font-bold text-slate-800">Community Support</h2>
            </div>
            <CommunityFeed />
          </div>
        </div>
      </main>

      <div className="fixed bottom-24 left-1/2 transform -translate-x-1/2 z-40">
        <div className="flex items-center gap-6 bg-white/90 backdrop-blur-md rounded-full p-3 shadow-2xl border border-white/20">
          <MoodSelector />
          <div className="w-px h-8 bg-slate-200"></div>
          <ChatButton />
        </div>
      </div>

      <div className="fixed bottom-24 right-8 z-40">
        <SOSButton />
      </div>
    </div>
  )
}
