"use client"

import { useState } from "react"
import { ArrowLeft, Plus, Heart, MessageCircle, Send } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { useRouter } from "next/navigation"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"

interface Post {
  id: number
  content: string
  timestamp: string
  supports: number
  replies: number
}

// Extended mock posts data
const initialPosts: Post[] = [
  {
    id: 1,
    content: "Today was challenging, but I managed to practice mindfulness for 10 minutes. Small steps count!",
    timestamp: "2 hours ago",
    supports: 12,
    replies: 3,
  },
  {
    id: 2,
    content: "Grateful for this community. Your support means everything during tough times. 💙",
    timestamp: "4 hours ago",
    supports: 28,
    replies: 7,
  },
  {
    id: 3,
    content: "Started journaling this week. It's amazing how writing down thoughts helps clear the mind.",
    timestamp: "6 hours ago",
    supports: 15,
    replies: 5,
  },
  {
    id: 4,
    content: "Reminder: It's okay to have bad days. Tomorrow is a new opportunity to try again.",
    timestamp: "8 hours ago",
    supports: 42,
    replies: 12,
  },
  {
    id: 5,
    content: "Finally reached out to a therapist today. Proud of myself for taking this step.",
    timestamp: "12 hours ago",
    supports: 67,
    replies: 18,
  },
  {
    id: 6,
    content: "Nature walk helped me feel grounded today. Sometimes the simplest things work best.",
    timestamp: "1 day ago",
    supports: 23,
    replies: 8,
  },
  {
    id: 7,
    content: "Meditation app recommendation: Headspace has been a game-changer for my anxiety management.",
    timestamp: "1 day ago",
    supports: 34,
    replies: 15,
  },
  {
    id: 8,
    content: "Bad day turned around after calling a friend. Connection really does heal.",
    timestamp: "2 days ago",
    supports: 19,
    replies: 6,
  },
]

export default function CommunityPage() {
  const [posts, setPosts] = useState<Post[]>(initialPosts)
  const [supportedPosts, setSupportedPosts] = useState<Set<number>>(new Set())
  const [newPost, setNewPost] = useState("")
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const router = useRouter()

  const handleSupport = (postId: number) => {
    setSupportedPosts((prev) => {
      const newSet = new Set(prev)
      if (newSet.has(postId)) {
        newSet.delete(postId)
      } else {
        newSet.add(postId)
      }
      return newSet
    })

    setPosts((prev) =>
      prev.map((post) =>
        post.id === postId
          ? {
              ...post,
              supports: supportedPosts.has(postId) ? post.supports - 1 : post.supports + 1,
            }
          : post,
      ),
    )
  }

  const handleCreatePost = () => {
    if (!newPost.trim()) return

    const post: Post = {
      id: Date.now(),
      content: newPost.trim(),
      timestamp: "Just now",
      supports: 0,
      replies: 0,
    }

    setPosts((prev) => [post, ...prev])
    setNewPost("")
    setIsDialogOpen(false)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-emerald-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-teal-500 to-emerald-500 text-white p-4 shadow-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => router.back()}
              className="text-white hover:bg-white/20 p-2"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="font-semibold text-lg">Community Posts</h1>
              <p className="text-sm text-white/80">Share your journey anonymously</p>
            </div>
          </div>

          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="ghost" size="sm" className="text-white hover:bg-white/20 p-2">
                <Plus className="h-5 w-5" />
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>Share Your Experience</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <Textarea
                  placeholder="Share what's on your mind... Your post will be anonymous."
                  value={newPost}
                  onChange={(e) => setNewPost(e.target.value)}
                  className="min-h-[120px] resize-none"
                  maxLength={500}
                />
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">{newPost.length}/500 characters</span>
                  <Button
                    onClick={handleCreatePost}
                    disabled={!newPost.trim()}
                    className="bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-600 hover:to-emerald-600"
                  >
                    <Send className="h-4 w-4 mr-2" />
                    Share
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Posts Feed */}
      <div className="p-4 max-w-2xl mx-auto">
        <div className="space-y-4">
          {posts.map((post) => (
            <Card
              key={post.id}
              className="shadow-sm border-0 bg-white/80 backdrop-blur-sm hover:shadow-md transition-all duration-200"
            >
              <CardContent className="p-4">
                <div className="space-y-3">
                  <p className="text-sm text-foreground leading-relaxed text-pretty">{post.content}</p>

                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <span>{post.timestamp}</span>
                    <span className="bg-gradient-to-r from-teal-500 to-emerald-500 bg-clip-text text-transparent font-medium">
                      Anonymous
                    </span>
                  </div>

                  <div className="flex items-center gap-4 pt-2 border-t border-border/30">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleSupport(post.id)}
                      className={`flex items-center gap-2 text-xs h-8 px-3 rounded-lg transition-all ${
                        supportedPosts.has(post.id)
                          ? "text-teal-600 bg-teal-50 hover:bg-teal-100"
                          : "text-muted-foreground hover:text-teal-600 hover:bg-teal-50"
                      }`}
                    >
                      <Heart className={`h-3 w-3 ${supportedPosts.has(post.id) ? "fill-current" : ""}`} />
                      <span>{post.supports} Support</span>
                    </Button>

                    <Button
                      variant="ghost"
                      size="sm"
                      className="flex items-center gap-2 text-xs h-8 px-3 rounded-lg text-muted-foreground hover:text-teal-600 hover:bg-teal-50 transition-all"
                    >
                      <MessageCircle className="h-3 w-3" />
                      <span>{post.replies} Replies</span>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Encouraging message at bottom */}
        <Card className="mt-8 bg-gradient-to-r from-teal-50 to-emerald-50 border-teal-200">
          <CardContent className="p-6 text-center">
            <h3 className="font-semibold text-teal-800 mb-2">You're Not Alone</h3>
            <p className="text-sm text-teal-700 leading-relaxed">
              This community is here to support you. Share your experiences, celebrate small wins, and remember that
              every step forward matters.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
