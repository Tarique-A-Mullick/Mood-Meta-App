import { streamText } from "ai"
import { xai } from "@ai-sdk/xai"
import type { NextRequest } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { messages } = await request.json()

    if (!messages || !Array.isArray(messages)) {
      return new Response("Messages array is required", { status: 400 })
    }

    const lastMessage = messages[messages.length - 1]

    const result = streamText({
      model: xai("grok-3", {
        apiKey: process.env.XAI_API_KEY,
      }),
      messages: messages,
      system: `You are MindCare AI, a compassionate and professional mental health support assistant. Your role is to:

- Provide empathetic, non-judgmental support and active listening
- Offer evidence-based coping strategies and mindfulness techniques
- Encourage professional help when appropriate
- Never diagnose or provide medical advice
- Maintain a warm, supportive, and hopeful tone
- Ask thoughtful follow-up questions to better understand the user's feelings
- Validate emotions and normalize mental health struggles
- Suggest healthy activities like journaling, breathing exercises, or gentle movement

Remember: You are a supportive companion, not a replacement for professional therapy or medical care. Always encourage users to seek professional help for serious concerns.`,
    })

    return result.toTextStreamResponse()
  } catch (error) {
    console.error("Error generating chat response:", error)
    return new Response("Failed to generate response", { status: 500 })
  }
}
