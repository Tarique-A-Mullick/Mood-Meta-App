"use client"

import { useState } from "react"
import { ArrowLeft, Phone, Users, Heart, MapPin, Clock, Shield, AlertTriangle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useRouter } from "next/navigation"
import { Separator } from "@/components/ui/separator"

export default function SOSPage() {
  const [familyContact, setFamilyContact] = useState("")
  const [friendContact, setFriendContact] = useState("")
  const router = useRouter()

  const handleCall = (number: string, type: string) => {
    if (number) {
      console.log(`Calling ${type}:`, number)
      window.open(`tel:${number}`)
    } else {
      alert(`Please add a ${type.toLowerCase()} contact first`)
    }
  }

  const handleEmergencyCall = (number: string, name: string) => {
    console.log(`Calling ${name}:`, number)
    window.open(`tel:${number}`)
  }

  const crisisResources = [
    {
      name: "National Suicide Prevention Lifeline",
      number: "988",
      description: "24/7 crisis support and suicide prevention",
      availability: "24/7",
    },
    {
      name: "Crisis Text Line",
      number: "741741",
      description: "Text HOME for crisis support",
      availability: "24/7",
      isText: true,
    },
    {
      name: "SAMHSA National Helpline",
      number: "1-800-662-4357",
      description: "Mental health and substance abuse support",
      availability: "24/7",
    },
    {
      name: "National Domestic Violence Hotline",
      number: "1-800-799-7233",
      description: "Support for domestic violence situations",
      availability: "24/7",
    },
  ]

  const copingStrategies = [
    "Take 5 deep breaths slowly",
    "Name 5 things you can see around you",
    "Call someone you trust",
    "Go to a safe, public place",
    "Practice grounding techniques",
    "Listen to calming music",
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-orange-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-red-500 to-orange-500 text-white p-4 shadow-lg">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="sm" onClick={() => router.back()} className="text-white hover:bg-white/20 p-2">
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <h1 className="font-semibold text-lg flex items-center gap-2">
              <Shield className="h-5 w-5" />
              SOS Emergency Support
            </h1>
            <p className="text-sm text-white/80">Immediate help and resources</p>
          </div>
        </div>
      </div>

      <div className="p-4 max-w-2xl mx-auto space-y-6">
        {/* Emergency Alert */}
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <AlertTriangle className="h-5 w-5 text-red-600 mt-0.5" />
              <div>
                <h3 className="font-semibold text-red-800 mb-1">In Immediate Danger?</h3>
                <p className="text-sm text-red-700 mb-3">
                  If you're in immediate physical danger or having thoughts of suicide, call emergency services now.
                </p>
                <Button
                  onClick={() => handleEmergencyCall("911", "Emergency Services")}
                  variant="destructive"
                  className="w-full font-semibold"
                >
                  <Phone className="h-4 w-4 mr-2" />
                  Call 911 Emergency
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Personal Contacts */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Users className="h-5 w-5 text-teal-600" />
              Your Support Network
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="flex items-center gap-3 mb-3">
                <Heart className="h-4 w-4 text-pink-500" />
                <Label className="font-medium">Family Contact</Label>
              </div>
              <div className="flex gap-2">
                <Input
                  placeholder="Enter family member's phone number"
                  value={familyContact}
                  onChange={(e) => setFamilyContact(e.target.value)}
                  className="flex-1"
                  type="tel"
                />
                <Button
                  onClick={() => handleCall(familyContact, "Family")}
                  className="bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-600 hover:to-emerald-600"
                >
                  <Phone className="h-4 w-4 mr-1" />
                  Call
                </Button>
              </div>
            </div>

            <Separator />

            <div>
              <div className="flex items-center gap-3 mb-3">
                <Users className="h-4 w-4 text-blue-500" />
                <Label className="font-medium">Friend Contact</Label>
              </div>
              <div className="flex gap-2">
                <Input
                  placeholder="Enter friend's phone number"
                  value={friendContact}
                  onChange={(e) => setFriendContact(e.target.value)}
                  className="flex-1"
                  type="tel"
                />
                <Button
                  onClick={() => handleCall(friendContact, "Friend")}
                  className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600"
                >
                  <Phone className="h-4 w-4 mr-1" />
                  Call
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Crisis Resources */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Phone className="h-5 w-5 text-red-600" />
              Crisis Helplines
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {crisisResources.map((resource, index) => (
              <div key={index} className="p-3 bg-gray-50 rounded-lg">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h4 className="font-medium text-sm">{resource.name}</h4>
                    <p className="text-xs text-gray-600 mt-1">{resource.description}</p>
                    <div className="flex items-center gap-4 mt-2">
                      <div className="flex items-center gap-1">
                        <Clock className="h-3 w-3 text-green-600" />
                        <span className="text-xs text-green-600">{resource.availability}</span>
                      </div>
                    </div>
                  </div>
                  <Button
                    onClick={() => handleEmergencyCall(resource.number, resource.name)}
                    size="sm"
                    variant={resource.isText ? "outline" : "destructive"}
                    className="ml-3"
                  >
                    {resource.isText ? "Text" : "Call"} {resource.number}
                  </Button>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Immediate Coping Strategies */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Heart className="h-5 w-5 text-pink-500" />
              Immediate Coping Strategies
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 gap-2">
              {copingStrategies.map((strategy, index) => (
                <div key={index} className="flex items-center gap-3 p-2 bg-pink-50 rounded-lg">
                  <div className="w-6 h-6 bg-pink-200 rounded-full flex items-center justify-center text-xs font-semibold text-pink-700">
                    {index + 1}
                  </div>
                  <span className="text-sm text-pink-800">{strategy}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Safety Planning */}
        <Card className="bg-gradient-to-r from-teal-50 to-emerald-50 border-teal-200">
          <CardContent className="p-6 text-center">
            <MapPin className="h-8 w-8 text-teal-600 mx-auto mb-3" />
            <h3 className="font-semibold text-teal-800 mb-2">Safety First</h3>
            <p className="text-sm text-teal-700 leading-relaxed mb-4">
              If you're in an unsafe situation, prioritize getting to a safe location. Trust your instincts and don't
              hesitate to ask for help.
            </p>
            <Button
              onClick={() => handleEmergencyCall("911", "Emergency Services")}
              variant="outline"
              className="border-teal-300 text-teal-700 hover:bg-teal-100"
            >
              <Phone className="h-4 w-4 mr-2" />
              Emergency Services: 911
            </Button>
          </CardContent>
        </Card>

        {/* Encouraging Message */}
        <Card className="bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200">
          <CardContent className="p-6 text-center">
            <h3 className="font-semibold text-purple-800 mb-2">You Are Not Alone</h3>
            <p className="text-sm text-purple-700 leading-relaxed">
              Reaching out for help is a sign of strength, not weakness. There are people who care about you and want to
              help. Your life has value and meaning.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
