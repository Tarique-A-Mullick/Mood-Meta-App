"use client"

import { useState } from "react"
import { DashboardHeader } from "@/components/dashboard-header"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Separator } from "@/components/ui/separator"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"
import { User, Settings, Phone, Moon, Sun, Edit, Save, LogOut, LogIn } from "lucide-react"

// Demo mood data for the profile graph
const demoMoodData = [
  { date: "Mon", mood: 7, day: "Monday" },
  { date: "Tue", mood: 6, day: "Tuesday" },
  { date: "Wed", mood: 8, day: "Wednesday" },
  { date: "Thu", mood: 5, day: "Thursday" },
  { date: "Fri", mood: 9, day: "Friday" },
  { date: "Sat", mood: 8, day: "Saturday" },
  { date: "Sun", mood: 7, day: "Sunday" },
]

const weeklyData = [
  { date: "Week 1", mood: 6.5, period: "Week 1" },
  { date: "Week 2", mood: 7.2, period: "Week 2" },
  { date: "Week 3", mood: 6.8, period: "Week 3" },
  { date: "Week 4", mood: 8.1, period: "Week 4" },
]

const monthlyData = [
  { date: "Jan", mood: 6.8, period: "January" },
  { date: "Feb", mood: 7.2, period: "February" },
  { date: "Mar", mood: 7.8, period: "March" },
  { date: "Apr", mood: 8.1, period: "April" },
]

export default function ProfilePage() {
  const [isLoggedIn, setIsLoggedIn] = useState(true)
  const [isDarkMode, setIsDarkMode] = useState(false)
  const [isEditing, setIsEditing] = useState(false)
  const [viewMode, setViewMode] = useState<"daily" | "weekly" | "monthly">("daily")
  const [sosContacts, setSosContacts] = useState([
    { name: "Mom", phone: "+1 (555) 123-4567", type: "Family" },
    { name: "Best Friend", phone: "+1 (555) 987-6543", type: "Friend" },
    { name: "Crisis Helpline", phone: "988", type: "Emergency" },
  ])

  const getCurrentData = () => {
    switch (viewMode) {
      case "weekly":
        return weeklyData
      case "monthly":
        return monthlyData
      default:
        return demoMoodData
    }
  }

  const handleDarkModeToggle = () => {
    setIsDarkMode(!isDarkMode)
    document.documentElement.classList.toggle("dark")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/30 to-card">
      <DashboardHeader />

      <main className="container mx-auto px-4 py-6 space-y-6 animate-fade-in">
        {/* Profile Header */}
        <Card className="gradient-card border-0 shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <Avatar className="w-20 h-20 border-4 border-primary/20">
                <AvatarImage src="/friendly-user-avatar.jpg" />
                <AvatarFallback className="text-2xl font-bold bg-gradient-primary text-white">
                  <User className="w-8 h-8" />
                </AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <h1 className="text-2xl font-bold text-foreground">Welcome back!</h1>
                <p className="text-muted-foreground">Your mental wellness journey</p>
                <div className="flex gap-2 mt-2">
                  <Badge variant="secondary" className="bg-primary/10 text-primary">
                    7-day streak
                  </Badge>
                  <Badge variant="outline">Premium Member</Badge>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Core Board - Mood Trends */}
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-gradient-primary flex items-center justify-center">
                  <User className="w-4 h-4 text-white" />
                </div>
                Core Board - Mood Trends
              </CardTitle>
              <div className="flex gap-2">
                {(["daily", "weekly", "monthly"] as const).map((mode) => (
                  <Button
                    key={mode}
                    variant={viewMode === mode ? "default" : "outline"}
                    size="sm"
                    onClick={() => setViewMode(mode)}
                    className="capitalize"
                  >
                    {mode}
                  </Button>
                ))}
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={getCurrentData()}>
                  <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                  <XAxis dataKey="date" />
                  <YAxis domain={[1, 10]} />
                  <Tooltip
                    labelFormatter={(label) =>
                      getCurrentData().find((d) => d.date === label)?.[viewMode === "daily" ? "day" : "period"] || label
                    }
                    formatter={(value) => [`${value}/10`, "Mood Score"]}
                  />
                  <Line
                    type="monotone"
                    dataKey="mood"
                    stroke="oklch(0.55 0.15 180)"
                    strokeWidth={3}
                    dot={{ fill: "oklch(0.55 0.15 180)", strokeWidth: 2, r: 6 }}
                    activeDot={{ r: 8, stroke: "oklch(0.65 0.12 270)", strokeWidth: 2 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Login/Logout & Settings */}
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="w-5 h-5" />
                Account & Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {isLoggedIn ? <LogOut className="w-4 h-4" /> : <LogIn className="w-4 h-4" />}
                  <span>{isLoggedIn ? "Sign Out" : "Sign In"}</span>
                </div>
                <Button
                  variant={isLoggedIn ? "destructive" : "default"}
                  size="sm"
                  onClick={() => setIsLoggedIn(!isLoggedIn)}
                >
                  {isLoggedIn ? "Logout" : "Login"}
                </Button>
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {isDarkMode ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
                  <span>Dark Mode</span>
                </div>
                <Switch checked={isDarkMode} onCheckedChange={handleDarkModeToggle} />
              </div>

              <Separator />

              <div className="space-y-2">
                <Label>Notification Preferences</Label>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Daily Mood Reminders</span>
                    <Switch defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Community Updates</span>
                    <Switch defaultChecked />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* SOS Contacts */}
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Phone className="w-5 h-5" />
                  SOS Contacts
                </CardTitle>
                <Button variant="outline" size="sm" onClick={() => setIsEditing(!isEditing)}>
                  {isEditing ? <Save className="w-4 h-4" /> : <Edit className="w-4 h-4" />}
                  {isEditing ? "Save" : "Edit"}
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              {sosContacts.map((contact, index) => (
                <div key={index} className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                  <div className="w-10 h-10 rounded-full bg-gradient-primary flex items-center justify-center">
                    <Phone className="w-4 h-4 text-white" />
                  </div>
                  <div className="flex-1">
                    {isEditing ? (
                      <div className="space-y-1">
                        <Input
                          value={contact.name}
                          className="h-8 text-sm"
                          onChange={(e) => {
                            const newContacts = [...sosContacts]
                            newContacts[index].name = e.target.value
                            setSosContacts(newContacts)
                          }}
                        />
                        <Input
                          value={contact.phone}
                          className="h-8 text-sm"
                          onChange={(e) => {
                            const newContacts = [...sosContacts]
                            newContacts[index].phone = e.target.value
                            setSosContacts(newContacts)
                          }}
                        />
                      </div>
                    ) : (
                      <>
                        <p className="font-medium text-sm">{contact.name}</p>
                        <p className="text-xs text-muted-foreground">{contact.phone}</p>
                      </>
                    )}
                  </div>
                  <Badge variant="outline" className="text-xs">
                    {contact.type}
                  </Badge>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
