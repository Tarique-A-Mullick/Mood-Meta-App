"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Smile, X, Calendar, Clock, Save } from "lucide-react"
import { Badge } from "@/components/ui/badge"

const moods = [
  { emoji: "😢", label: "Sad", value: 2, color: "bg-blue-100 text-blue-800" },
  { emoji: "😟", label: "Worried", value: 3, color: "bg-orange-100 text-orange-800" },
  { emoji: "😐", label: "Neutral", value: 5, color: "bg-gray-100 text-gray-800" },
  { emoji: "🙂", label: "Content", value: 6, color: "bg-green-100 text-green-800" },
  { emoji: "😊", label: "Happy", value: 7, color: "bg-emerald-100 text-emerald-800" },
  { emoji: "😄", label: "Joyful", value: 8, color: "bg-teal-100 text-teal-800" },
  { emoji: "🤗", label: "Grateful", value: 9, color: "bg-purple-100 text-purple-800" },
  { emoji: "😡", label: "Angry", value: 3, color: "bg-red-100 text-red-800" },
  { emoji: "😰", label: "Anxious", value: 2, color: "bg-yellow-100 text-yellow-800" },
  { emoji: "🤔", label: "Confused", value: 4, color: "bg-indigo-100 text-indigo-800" },
  { emoji: "😴", label: "Tired", value: 4, color: "bg-slate-100 text-slate-800" },
  { emoji: "🥳", label: "Excited", value: 9, color: "bg-pink-100 text-pink-800" },
]

const moodTriggers = [
  "Work/School",
  "Relationships",
  "Health",
  "Family",
  "Money",
  "Sleep",
  "Exercise",
  "Weather",
  "Social Media",
  "News",
  "Personal Goals",
  "Other",
]

const activities = [
  "Meditation",
  "Exercise",
  "Reading",
  "Music",
  "Talking to someone",
  "Journaling",
  "Walking",
  "Breathing exercises",
  "Creative work",
  "Resting",
  "Eating well",
  "Other",
]

export function MoodSelector() {
  const [isOpen, setIsOpen] = useState(false)
  const [selectedMood, setSelectedMood] = useState<(typeof moods)[0] | null>(null)
  const [step, setStep] = useState<"mood" | "details">("mood")
  const [note, setNote] = useState("")
  const [selectedTriggers, setSelectedTriggers] = useState<string[]>([])
  const [selectedActivities, setSelectedActivities] = useState<string[]>([])
  const [isLoading, setIsLoading] = useState(false)

  const handleMoodSelect = (mood: (typeof moods)[0]) => {
    setSelectedMood(mood)
    setStep("details")
  }

  const toggleTrigger = (trigger: string) => {
    setSelectedTriggers((prev) => (prev.includes(trigger) ? prev.filter((t) => t !== trigger) : [...prev, trigger]))
  }

  const toggleActivity = (activity: string) => {
    setSelectedActivities((prev) =>
      prev.includes(activity) ? prev.filter((a) => a !== activity) : [...prev, activity],
    )
  }

  const handleSave = async () => {
    if (!selectedMood) return

    setIsLoading(true)

    const moodEntry = {
      mood: selectedMood,
      note: note.trim(),
      triggers: selectedTriggers,
      activities: selectedActivities,
      timestamp: new Date().toISOString(),
    }

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    console.log("Mood entry saved:", moodEntry)

    // Reset form
    setSelectedMood(null)
    setNote("")
    setSelectedTriggers([])
    setSelectedActivities([])
    setStep("mood")
    setIsOpen(false)
    setIsLoading(false)
  }

  const handleBack = () => {
    setStep("mood")
    setSelectedMood(null)
  }

  const resetAndClose = () => {
    setSelectedMood(null)
    setNote("")
    setSelectedTriggers([])
    setSelectedActivities([])
    setStep("mood")
    setIsOpen(false)
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button
          size="lg"
          className="h-14 w-14 rounded-full gradient-primary shadow-lg hover:shadow-xl transition-all duration-200 hover:scale-105"
        >
          <Smile className="h-6 w-6" />
          <span className="sr-only">Select mood</span>
        </Button>
      </DialogTrigger>

      <DialogContent className="sm:max-w-lg bg-card/95 backdrop-blur border-0 shadow-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="text-lg font-semibold flex items-center gap-2">
              {step === "mood" ? (
                <>
                  <Smile className="h-5 w-5 text-primary" />
                  How are you feeling?
                </>
              ) : (
                <>
                  <Calendar className="h-5 w-5 text-primary" />
                  Tell us more
                </>
              )}
            </DialogTitle>
            <Button variant="ghost" size="icon" onClick={resetAndClose} className="h-6 w-6 rounded-full">
              <X className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>

        {step === "mood" && (
          <div className="space-y-4">
            <div className="grid grid-cols-3 gap-3 py-4">
              {moods.map((mood) => (
                <Button
                  key={mood.label}
                  variant="ghost"
                  onClick={() => handleMoodSelect(mood)}
                  className="h-20 flex flex-col items-center justify-center gap-2 rounded-xl hover:bg-primary/10 hover:scale-105 transition-all duration-200"
                >
                  <span className="text-2xl">{mood.emoji}</span>
                  <span className="text-xs font-medium text-muted-foreground">{mood.label}</span>
                </Button>
              ))}
            </div>

            <div className="text-center text-sm text-muted-foreground flex items-center justify-center gap-2">
              <Clock className="h-4 w-4" />
              {new Date().toLocaleDateString()} •{" "}
              {new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
            </div>
          </div>
        )}

        {step === "details" && selectedMood && (
          <div className="space-y-6 py-4">
            <div className="text-center p-4 bg-gradient-to-r from-primary/10 to-secondary/10 rounded-xl">
              <div className="text-4xl mb-2">{selectedMood.emoji}</div>
              <Badge className={selectedMood.color}>{selectedMood.label}</Badge>
            </div>

            <div className="space-y-2">
              <Label className="text-sm font-medium">What's on your mind? (Optional)</Label>
              <Textarea
                placeholder="Share what's happening or how you're feeling..."
                value={note}
                onChange={(e) => setNote(e.target.value)}
                className="min-h-[80px] resize-none"
                maxLength={300}
              />
              <div className="text-xs text-muted-foreground text-right">{note.length}/300</div>
            </div>

            <div className="space-y-3">
              <Label className="text-sm font-medium">What might have influenced this mood?</Label>
              <div className="flex flex-wrap gap-2">
                {moodTriggers.map((trigger) => (
                  <Button
                    key={trigger}
                    variant={selectedTriggers.includes(trigger) ? "default" : "outline"}
                    size="sm"
                    onClick={() => toggleTrigger(trigger)}
                    className="text-xs h-8 rounded-full"
                  >
                    {trigger}
                  </Button>
                ))}
              </div>
            </div>

            <div className="space-y-3">
              <Label className="text-sm font-medium">What helped or might help?</Label>
              <div className="flex flex-wrap gap-2">
                {activities.map((activity) => (
                  <Button
                    key={activity}
                    variant={selectedActivities.includes(activity) ? "secondary" : "outline"}
                    size="sm"
                    onClick={() => toggleActivity(activity)}
                    className="text-xs h-8 rounded-full"
                  >
                    {activity}
                  </Button>
                ))}
              </div>
            </div>

            <div className="flex gap-3 pt-4">
              <Button variant="outline" onClick={handleBack} className="flex-1 bg-transparent">
                Back
              </Button>
              <Button
                onClick={handleSave}
                disabled={isLoading}
                className="flex-1 bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-600 hover:to-emerald-600"
              >
                {isLoading ? (
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    Saving...
                  </div>
                ) : (
                  <>
                    <Save className="h-4 w-4 mr-2" />
                    Save Entry
                  </>
                )}
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}
