"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from "recharts"
import { TrendingUp, Calendar, BarChart3 } from "lucide-react"

const dailyData = [
  { date: "Mon", mood: 7.2, label: "Happy" },
  { date: "Tue", mood: 5.8, label: "Neutral" },
  { date: "Wed", mood: 8.4, label: "Great" },
  { date: "Thu", mood: 4.2, label: "Low" },
  { date: "Fri", mood: 6.9, label: "Good" },
  { date: "Sat", mood: 9.1, label: "Excellent" },
  { date: "Sun", mood: 7.6, label: "Happy" },
]

const weeklyData = [
  { date: "Week 1", mood: 6.8, label: "Good" },
  { date: "Week 2", mood: 7.4, label: "Happy" },
  { date: "Week 3", mood: 5.9, label: "Neutral" },
  { date: "Week 4", mood: 8.2, label: "Great" },
  { date: "Week 5", mood: 7.8, label: "Happy" },
  { date: "Week 6", mood: 8.6, label: "Excellent" },
]

const monthlyData = [
  { date: "Jan", mood: 6.4, label: "Good" },
  { date: "Feb", mood: 7.2, label: "Happy" },
  { date: "Mar", mood: 6.9, label: "Good" },
  { date: "Apr", mood: 8.1, label: "Great" },
  { date: "May", mood: 7.8, label: "Happy" },
  { date: "Jun", mood: 8.7, label: "Excellent" },
  { date: "Jul", mood: 8.3, label: "Great" },
  { date: "Aug", mood: 7.9, label: "Happy" },
]

type ViewType = "daily" | "weekly" | "monthly"

export function MoodGraph() {
  const [view, setView] = useState<ViewType>("daily")

  const getData = () => {
    switch (view) {
      case "weekly":
        return weeklyData
      case "monthly":
        return monthlyData
      default:
        return dailyData
    }
  }

  const getMoodColor = (mood: number) => {
    if (mood >= 8) return "#10b981" // Emerald for excellent mood
    if (mood >= 6) return "#3b82f6" // Blue for good mood
    if (mood >= 4) return "#f59e0b" // Amber for neutral mood
    return "#ef4444" // Red for low mood
  }

  const getViewIcon = (viewType: ViewType) => {
    switch (viewType) {
      case "daily":
        return <Calendar className="w-3 h-3" />
      case "weekly":
        return <BarChart3 className="w-3 h-3" />
      case "monthly":
        return <TrendingUp className="w-3 h-3" />
    }
  }

  const currentData = getData()
  const latestMood = currentData[currentData.length - 1]
  const averageMood = (currentData.reduce((sum, item) => sum + item.mood, 0) / currentData.length).toFixed(1)

  return (
    <div className="space-y-6">
      <Card className="h-full shadow-xl border-0 bg-gradient-to-br from-white/90 to-purple-50/80 backdrop-blur-sm overflow-hidden">
        <CardHeader className="pb-3 relative">
          <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-purple-200/30 to-transparent rounded-full -translate-y-16 translate-x-16" />

          <div className="flex items-center justify-between relative z-10">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-gradient-to-r from-purple-500 to-blue-500 rounded-lg">
                <TrendingUp className="w-4 h-4 text-white" />
              </div>
              <CardTitle className="text-lg font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                Mood Trends
              </CardTitle>
            </div>

            <div className="flex gap-1 bg-white/60 backdrop-blur-sm rounded-xl p-1 shadow-sm border border-white/20">
              {(["daily", "weekly", "monthly"] as ViewType[]).map((period) => (
                <Button
                  key={period}
                  variant={view === period ? "default" : "ghost"}
                  size="sm"
                  onClick={() => setView(period)}
                  className={`text-xs px-3 py-2 rounded-lg transition-all duration-200 flex items-center gap-1.5 ${
                    view === period
                      ? "bg-purple-600 hover:bg-purple-700 text-white shadow-md hover:shadow-lg transform hover:scale-105"
                      : "hover:bg-white/50 text-slate-800 hover:text-slate-900 font-medium"
                  }`}
                >
                  {getViewIcon(period)}
                  {period.charAt(0).toUpperCase() + period.slice(1)}
                </Button>
              ))}
            </div>
          </div>
        </CardHeader>

        <CardContent className="pt-0 pb-4">
          <div className="h-72 w-full mb-4 bg-white/40 backdrop-blur-sm rounded-xl p-4 border border-white/20">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={currentData} margin={{ top: 10, right: 30, left: 20, bottom: 10 }}>
                <defs>
                  <linearGradient id="moodGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0.1} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" opacity={0.6} />
                <XAxis
                  dataKey="date"
                  stroke="#64748b"
                  fontSize={11}
                  fontWeight={500}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis
                  domain={[0, 10]}
                  stroke="#64748b"
                  fontSize={11}
                  fontWeight={500}
                  axisLine={false}
                  tickLine={false}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "rgba(255, 255, 255, 0.95)",
                    border: "1px solid rgba(139, 92, 246, 0.2)",
                    borderRadius: "12px",
                    boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)",
                    backdropFilter: "blur(10px)",
                  }}
                  formatter={(value: number, name: string, props: any) => [
                    `${value}/10 - ${props.payload.label}`,
                    "Mood Score",
                  ]}
                  labelStyle={{ color: "#374151", fontWeight: "600" }}
                />
                <Area
                  type="monotone"
                  dataKey="mood"
                  stroke="url(#gradient)"
                  strokeWidth={3}
                  fill="url(#moodGradient)"
                  dot={{ fill: "#8b5cf6", strokeWidth: 2, r: 5, stroke: "#ffffff" }}
                  activeDot={{ r: 7, stroke: "#8b5cf6", strokeWidth: 3, fill: "#ffffff" }}
                />
                <defs>
                  <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#8b5cf6" />
                    <stop offset="100%" stopColor="#3b82f6" />
                  </linearGradient>
                </defs>
              </AreaChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="p-4 bg-gradient-to-br from-emerald-50 to-emerald-100/50 rounded-xl border border-emerald-200/50">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-emerald-600 uppercase tracking-wide">Current Mood</p>
                  <p className="text-xl font-bold text-emerald-800 mt-1">{latestMood?.label || "Happy"}</p>
                </div>
                <div className="text-right">
                  <div className="w-12 h-12 bg-emerald-700 rounded-full flex items-center justify-center shadow-lg">
                    <span className="text-white font-bold text-sm">{latestMood?.mood || 7}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-4 bg-gradient-to-br from-blue-50 to-blue-100/50 rounded-xl border border-blue-200/50">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-blue-600 uppercase tracking-wide">Average</p>
                  <p className="text-xl font-bold text-blue-800 mt-1">{averageMood}/10</p>
                </div>
                <div className="text-right">
                  <div className="w-12 h-12 bg-blue-700 rounded-full flex items-center justify-center shadow-lg">
                    <TrendingUp className="w-5 h-5 text-white" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
