"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Phone, Users, Heart, X } from "lucide-react"

export function SOSButton() {
  const [isOpen, setIsOpen] = useState(false)
  const [familyContact, setFamilyContact] = useState("")
  const [friendContact, setFriendContact] = useState("")

  const handleCall = (number: string, type: string) => {
    if (number) {
      console.log(`Calling ${type}:`, number)
      // In a real app, this would initiate a phone call
      window.open(`tel:${number}`)
    } else {
      alert(`Please add a ${type.toLowerCase()} contact first`)
    }
  }

  const handleEmergencyCall = () => {
    console.log("Calling emergency helpline")
    // Emergency helpline number - this should be a real crisis helpline
    window.open("tel:988") // National Suicide Prevention Lifeline
  }

  return (
    <>
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogTrigger asChild>
          <Button
            size="lg"
            variant="destructive"
            className="fixed bottom-6 right-6 h-14 w-14 rounded-full bg-destructive hover:bg-destructive/90 shadow-lg hover:shadow-xl transition-all duration-200 hover:scale-105"
          >
            <Phone className="h-6 w-6" />
            <span className="sr-only">SOS Emergency</span>
          </Button>
        </DialogTrigger>

        <DialogContent className="sm:max-w-md bg-card/95 backdrop-blur border-0 shadow-2xl">
          <DialogHeader>
            <div className="flex items-center justify-between">
              <DialogTitle className="text-lg font-semibold text-destructive">Emergency Support</DialogTitle>
              <Button variant="ghost" size="icon" onClick={() => setIsOpen(false)} className="h-6 w-6 rounded-full">
                <X className="h-4 w-4" />
              </Button>
            </div>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <Card className="border border-border/50">
              <CardContent className="p-4">
                <div className="flex items-center gap-3 mb-3">
                  <Heart className="h-5 w-5 text-primary" />
                  <Label className="font-medium">Family</Label>
                </div>
                <div className="flex gap-2">
                  <Input
                    placeholder="Add family contact"
                    value={familyContact}
                    onChange={(e) => setFamilyContact(e.target.value)}
                    className="flex-1"
                  />
                  <Button onClick={() => handleCall(familyContact, "Family")} className="gradient-primary">
                    Call
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="border border-border/50">
              <CardContent className="p-4">
                <div className="flex items-center gap-3 mb-3">
                  <Users className="h-5 w-5 text-secondary" />
                  <Label className="font-medium">Friends</Label>
                </div>
                <div className="flex gap-2">
                  <Input
                    placeholder="Add friend contact"
                    value={friendContact}
                    onChange={(e) => setFriendContact(e.target.value)}
                    className="flex-1"
                  />
                  <Button
                    onClick={() => handleCall(friendContact, "Friend")}
                    className="bg-secondary hover:bg-secondary/90"
                  >
                    Call
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="border border-destructive/50 bg-destructive/5">
              <CardContent className="p-4">
                <div className="flex items-center gap-3 mb-3">
                  <Phone className="h-5 w-5 text-destructive" />
                  <Label className="font-medium text-destructive">Crisis Helpline</Label>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">National Crisis Line</p>
                    <p className="text-xs text-muted-foreground">24/7 Support Available</p>
                  </div>
                  <Button onClick={handleEmergencyCall} variant="destructive" className="font-semibold">
                    Call 988
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="text-center text-xs text-muted-foreground">You are not alone. Help is always available.</div>
        </DialogContent>
      </Dialog>
    </>
  )
}
