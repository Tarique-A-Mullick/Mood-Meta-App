"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Eye, EyeOff, Mail, Lock, Sparkles } from "lucide-react"

export function LoginForm() {
  const [showPassword, setShowPassword] = useState(false)
  const [isLogin, setIsLogin] = useState(true)
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // TODO: Implement authentication logic
    console.log("Form submitted:", { email, password, isLogin })

    // For now, redirect to dashboard (will be implemented in next task)
    if (typeof window !== "undefined") {
      window.location.href = "/dashboard"
    }
  }

  return (
    <Card className="w-full shadow-2xl border-0 bg-white/90 backdrop-blur-md relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-purple-50/50 to-teal-50/50 pointer-events-none"></div>

      <CardHeader className="space-y-1 text-center relative z-10">
        <CardTitle className="text-2xl font-bold flex items-center justify-center gap-2">
          <Sparkles className="h-5 w-5 text-purple-500" />
          {isLogin ? "Welcome Back" : "Join Mood Meta"}
          <Sparkles className="h-5 w-5 text-teal-500" />
        </CardTitle>
        <CardDescription className="text-slate-600 text-base">
          {isLogin ? "Continue your wellness journey" : "Start your mental wellness journey today"}
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-6 relative z-10">
        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="space-y-2">
            <Label htmlFor="email" className="text-sm font-semibold text-slate-700">
              Email Address
            </Label>
            <div className="relative group">
              <Mail className="absolute left-4 top-1/2 transform -translate-y-1/2 text-slate-400 group-focus-within:text-purple-500 h-5 w-5 transition-colors" />
              <Input
                id="email"
                type="email"
                placeholder="your@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="pl-12 h-14 rounded-2xl border-2 border-slate-200 focus:border-purple-400 focus:ring-4 focus:ring-purple-100 transition-all duration-200 text-base bg-white/80"
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="password" className="text-sm font-semibold text-slate-700">
              Password
            </Label>
            <div className="relative group">
              <Lock className="absolute left-4 top-1/2 transform -translate-y-1/2 text-slate-400 group-focus-within:text-purple-500 h-5 w-5 transition-colors" />
              <Input
                id="password"
                type={showPassword ? "text" : "password"}
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="pl-12 pr-12 h-14 rounded-2xl border-2 border-slate-200 focus:border-purple-400 focus:ring-4 focus:ring-purple-100 transition-all duration-200 text-base bg-white/80"
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-4 top-1/2 transform -translate-y-1/2 text-slate-400 hover:text-purple-500 transition-colors p-1"
              >
                {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
              </button>
            </div>
          </div>

          {!isLogin && (
            <div className="space-y-2">
              <Label htmlFor="confirmPassword" className="text-sm font-semibold text-slate-700">
                Confirm Password
              </Label>
              <div className="relative group">
                <Lock className="absolute left-4 top-1/2 transform -translate-y-1/2 text-slate-400 group-focus-within:text-purple-500 h-5 w-5 transition-colors" />
                <Input
                  id="confirmPassword"
                  type={showPassword ? "text" : "password"}
                  placeholder="Confirm your password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="pl-12 h-14 rounded-2xl border-2 border-slate-200 focus:border-purple-400 focus:ring-4 focus:ring-purple-100 transition-all duration-200 text-base bg-white/80"
                  required
                />
              </div>
            </div>
          )}

          <Button
            type="submit"
            className="w-full h-14 rounded-2xl bg-gradient-to-r from-purple-600 to-teal-600 hover:from-purple-700 hover:to-teal-700 text-white font-bold text-lg shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-[1.02] active:scale-[0.98]"
          >
            {isLogin ? "Sign In to Mood Meta" : "Create Your Account"}
          </Button>
        </form>

        <div className="text-center pt-6 border-t border-slate-200">
          <p className="text-sm text-slate-600 mb-2">{isLogin ? "New to Mood Meta?" : "Already have an account?"}</p>
          <Button
            variant="ghost"
            onClick={() => setIsLogin(!isLogin)}
            className="text-purple-600 hover:text-purple-700 hover:bg-purple-50 font-semibold px-6 py-2 rounded-xl transition-all duration-200"
          >
            {isLogin ? "Create Account" : "Sign In Instead"}
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
