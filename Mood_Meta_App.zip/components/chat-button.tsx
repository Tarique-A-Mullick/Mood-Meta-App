"use client"

import { Button } from "@/components/ui/button"
import { MessageCircle } from "lucide-react"
import { useRouter } from "next/navigation"

export function ChatButton() {
  const router = useRouter()

  const handleChatOpen = () => {
    router.push("/chat")
  }

  return (
    <Button
      onClick={handleChatOpen}
      size="lg"
      variant="secondary"
      className="h-14 w-14 rounded-full bg-secondary/80 hover:bg-secondary shadow-lg hover:shadow-xl transition-all duration-200 hover:scale-105"
    >
      <MessageCircle className="h-6 w-6" />
      <span className="sr-only">Open AI chat</span>
    </Button>
  )
}
