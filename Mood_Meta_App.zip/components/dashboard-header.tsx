"use client"

import { useState } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Menu, Home, Stethoscope, MessageCircle, Heart, Users, Phone, User } from "lucide-react"
import { useRouter } from "next/navigation"

export function DashboardHeader() {
  const [isOpen, setIsOpen] = useState(false)
  const router = useRouter()

  const menuItems = [
    { icon: Home, label: "Home", href: "/dashboard" },
    { icon: Stethoscope, label: "Services", href: "/services" },
    { icon: MessageCircle, label: "AI Chat Board", href: "/chat" },
    { icon: Heart, label: "Mood Tracker", href: "/mood-tracker" },
    { icon: Users, label: "Community Posts", href: "/community" },
    { icon: Phone, label: "SOS Help", href: "/sos" },
  ]

  const handleNavigation = (href: string) => {
    router.push(href)
    setIsOpen(false)
  }

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/60">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="relative w-10 h-10">
            <Image src="/logo.png" alt="Mood Meta Logo" fill className="object-contain" />
          </div>
          <span className="font-bold text-xl bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Mood Meta
          </span>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="icon"
            className="h-10 w-10 hover:bg-primary/10"
            onClick={() => router.push("/profile")}
          >
            <User className="h-5 w-5" />
            <span className="sr-only">Profile</span>
          </Button>

          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="h-10 w-10 hover:bg-primary/10">
                <Menu className="h-5 w-5" />
                <span className="sr-only">Toggle menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-80 bg-card/95 backdrop-blur animate-slide-up">
              <div className="flex flex-col h-full">
                <div className="flex items-center gap-3 pb-6 border-b border-border/50">
                  <div className="relative w-12 h-12">
                    <Image src="/logo.png" alt="Mood Meta Logo" fill className="object-contain" />
                  </div>
                  <div>
                    <h2 className="font-bold text-xl bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                      Mood Meta
                    </h2>
                    <p className="text-sm text-muted-foreground">Wellness Menu</p>
                  </div>
                </div>

                <nav className="flex-1 py-6">
                  <ul className="space-y-2">
                    {menuItems.map((item) => (
                      <li key={item.label}>
                        <Button
                          variant="ghost"
                          className="w-full justify-start h-12 text-left font-medium hover:bg-primary/10 hover:text-primary transition-all duration-200 rounded-xl"
                          onClick={() => handleNavigation(item.href)}
                        >
                          <item.icon className="mr-3 h-5 w-5" />
                          {item.label}
                        </Button>
                      </li>
                    ))}
                  </ul>
                </nav>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  )
}
