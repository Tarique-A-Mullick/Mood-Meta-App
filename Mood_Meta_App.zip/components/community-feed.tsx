"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Heart, MessageCircle } from "lucide-react"
import { useState } from "react"

// Mock community posts data
const mockPosts = [
  {
    id: 1,
    content: "Today was challenging, but I managed to practice mindfulness for 10 minutes. Small steps count!",
    timestamp: "2 hours ago",
    supports: 12,
    replies: 3,
  },
  {
    id: 2,
    content: "Grateful for this community. Your support means everything during tough times. 💙",
    timestamp: "4 hours ago",
    supports: 28,
    replies: 7,
  },
  {
    id: 3,
    content: "Started journaling this week. It's amazing how writing down thoughts helps clear the mind.",
    timestamp: "6 hours ago",
    supports: 15,
    replies: 5,
  },
  {
    id: 4,
    content: "Reminder: It's okay to have bad days. Tomorrow is a new opportunity to try again.",
    timestamp: "8 hours ago",
    supports: 42,
    replies: 12,
  },
  {
    id: 5,
    content: "Finally reached out to a therapist today. Proud of myself for taking this step.",
    timestamp: "12 hours ago",
    supports: 67,
    replies: 18,
  },
  {
    id: 6,
    content: "Nature walk helped me feel grounded today. Sometimes the simplest things work best.",
    timestamp: "1 day ago",
    supports: 23,
    replies: 8,
  },
]

export function CommunityFeed() {
  const [supportedPosts, setSupportedPosts] = useState<Set<number>>(new Set())

  const handleSupport = (postId: number) => {
    setSupportedPosts((prev) => {
      const newSet = new Set(prev)
      if (newSet.has(postId)) {
        newSet.delete(postId)
      } else {
        newSet.add(postId)
      }
      return newSet
    })
  }

  return (
    <div className="h-full">
      <Card className="h-full shadow-lg border-0 bg-card/80 backdrop-blur-sm">
        <CardContent className="p-0">
          <div className="h-[500px] overflow-y-auto scrollbar-thin scrollbar-thumb-primary/20 scrollbar-track-transparent">
            <div className="p-4 space-y-4">
              {mockPosts.map((post) => (
                <div
                  key={post.id}
                  className="p-4 bg-background/50 rounded-xl border border-border/30 hover:border-primary/20 transition-all duration-200 hover:shadow-md"
                >
                  <div className="space-y-3">
                    <p className="text-sm text-foreground leading-relaxed text-pretty">{post.content}</p>

                    <div className="flex items-center justify-between text-xs text-muted-foreground">
                      <span>{post.timestamp}</span>
                      <span>Anonymous</span>
                    </div>

                    <div className="flex items-center gap-4 pt-2 border-t border-border/30">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleSupport(post.id)}
                        className={`flex items-center gap-2 text-xs h-8 px-3 rounded-lg transition-all ${
                          supportedPosts.has(post.id)
                            ? "text-primary bg-primary/10 hover:bg-primary/20"
                            : "text-muted-foreground hover:text-primary hover:bg-primary/10"
                        }`}
                      >
                        <Heart className={`h-3 w-3 ${supportedPosts.has(post.id) ? "fill-current" : ""}`} />
                        <span>{post.supports + (supportedPosts.has(post.id) ? 1 : 0)} Support</span>
                      </Button>

                      <Button
                        variant="ghost"
                        size="sm"
                        className="flex items-center gap-2 text-xs h-8 px-3 rounded-lg text-muted-foreground hover:text-primary hover:bg-primary/10 transition-all"
                      >
                        <MessageCircle className="h-3 w-3" />
                        <span>{post.replies} Replies</span>
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
